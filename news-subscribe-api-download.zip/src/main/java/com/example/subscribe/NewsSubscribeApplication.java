package com.example.subscribe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsSubscribeApplication {
    public static void main(String[] args) {
        SpringApplication.run(NewsSubscribeApplication.class, args);
    }
}