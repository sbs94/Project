package com.example.subscribe.repository;

import com.example.subscribe.entity.Subscribe;
import com.example.subscribe.entity.User;
import com.example.subscribe.entity.Keyword;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscribeRepository extends JpaRepository<Subscribe, Long> {
    boolean existsByUserAndKeyword(User user, Keyword keyword);
}