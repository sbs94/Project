package com.example.subscribe.service;

import com.example.subscribe.dto.SubscribeRequest;
import com.example.subscribe.entity.User;
import com.example.subscribe.entity.Keyword;
import com.example.subscribe.entity.Subscribe;
import com.example.subscribe.repository.UserRepository;
import com.example.subscribe.repository.KeywordRepository;
import com.example.subscribe.repository.SubscribeRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SubscribeService {

    private final UserRepository userRepository;
    private final KeywordRepository keywordRepository;
    private final SubscribeRepository subscribeRepository;

    @Transactional
    public void subscribeUser(SubscribeRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseGet(() -> {
                    User newUser = new User();
                    newUser.setEmail(request.getEmail());
                    return userRepository.save(newUser);
                });

        for (String keywordStr : request.getKeywords()) {
            String trimmed = keywordStr.trim();

            Keyword keyword = keywordRepository.findByKeyword(trimmed)
                    .orElseGet(() -> {
                        Keyword newKeyword = new Keyword();
                        newKeyword.setKeyword(trimmed);
                        newKeyword.setSubscribeCount(1);
                        return keywordRepository.save(newKeyword);
                    });

            if (!subscribeRepository.existsByUserAndKeyword(user, keyword)) {
                Subscribe subscribe = new Subscribe();
                subscribe.setUser(user);
                subscribe.setKeyword(keyword);
                subscribeRepository.save(subscribe);

                keyword.setSubscribeCount(keyword.getSubscribeCount() + 1);
                keywordRepository.save(keyword);
            }
        }
    }
}