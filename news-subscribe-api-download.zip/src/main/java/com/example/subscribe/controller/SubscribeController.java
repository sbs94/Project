package com.example.subscribe.controller;

import com.example.subscribe.dto.SubscribeRequest;
import com.example.subscribe.service.SubscribeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class SubscribeController {

    private final SubscribeService subscribeService;

    @PostMapping("/subscribe")
    public ResponseEntity<String> subscribe(@RequestBody SubscribeRequest request) {
        subscribeService.subscribeUser(request);
        return ResponseEntity.ok("구독 등록 완료");
    }
}