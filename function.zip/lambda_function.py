import pymysql
import boto3
from datetime import datetime

# ✅ DB 연결 정보
DB_HOST = 'ns-rds.cb0ueo6m8a54.ap-northeast-2.rds.amazonaws.com'
DB_USER = 'root'
DB_PASSWORD = 'soldesk12!'
DB_NAME = 'NewsSubscribe'

# ✅ SNS Topic ARN (🔴 수정 필요)
SNS_TOPIC_ARN = 'arn:aws:sns:ap-northeast-2:635140758252:TEST2'

sns = boto3.client('sns')

def lambda_handler(event, context):
    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        db=DB_NAME,
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

    try:
        with conn.cursor() as cursor:
            # 1. 전송되지 않은 뉴스 조회
            cursor.execute("""
                SELECT c.id AS crolling_id, c.keyword_id, n.title, n.link
                FROM crolling c
                JOIN news n ON c.id = n.crolling_id
                WHERE c.is_send = 0
            """)
            news_list = cursor.fetchall()

            for news in news_list:
                crolling_id = news['crolling_id']
                keyword_id = news['keyword_id']
                title = news['title']
                link = news['link']

                message = f"[뉴스 알림]\n제목: {title}\n링크: {link}"
                subject = f"[뉴스] 키워드({keyword_id}) 관련 소식이 도착했습니다"

                success = False  # 초기 전송 상태

                # 🔁 최대 3회 재시도
                for attempt in range(3):
                    try:
                        sns.publish(
                            TopicArn=SNS_TOPIC_ARN,
                            Subject=subject,
                            Message=message
                        )
                        success = True
                        print(f"[전송 성공] 시도 {attempt+1}회: crolling_id={crolling_id}")
                        break  # 전송 성공 → 루프 종료
                    except Exception as e:
                        print(f"[전송 실패 - 시도 {attempt+1}] crolling_id={crolling_id} - {str(e)}")

                # 2. 사용자 목록 조회
                cursor.execute("""
                    SELECT u.id AS user_id
                    FROM users u
                    JOIN subscribe s ON u.id = s.user_id
                    WHERE s.keyword_id = %s
                """, (keyword_id,))
                users = cursor.fetchall()

                for user in users:
                    status_id = 2 if success else 3  # 2: 성공, 3: 실패
                    cursor.execute("""
                        INSERT IGNORE INTO send_history (user_id, crolling_id, send_status_id, sent_at)
                        VALUES (%s, %s, %s, %s)
                    """, (user['user_id'], crolling_id, status_id, datetime.now()))

                # 3. is_send 상태 업데이트 (무조건 전송 시도 완료로 간주)
                cursor.execute("UPDATE crolling SET is_send = 1 WHERE id = %s", (crolling_id,))

        conn.commit()

    finally:
        conn.close()
