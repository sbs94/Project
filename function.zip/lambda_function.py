# ---------- 기본 의존 ----------
import enum, json, pymysql, boto3, traceback
from datetime import datetime, timezone
from contextlib import contextmanager
from collections import defaultdict

# ---------- DB 설정 ----------
DB = dict(
    host="ns-rds.cb0ueo6m8a54.ap-northeast-2.rds.amazonaws.com",
    user="root",
    password="soldesk12!",
    database="NewsSubscribe",
    charset="utf8mb4",
    cursorclass=pymysql.cursors.DictCursor
)

# ---------- SES 설정 ----------
ses = boto3.client("ses", region_name="ap-northeast-2")
SES_SENDER = "fun.helen3914@gmail.com"  # ✅ 인증된 발신자 주소

# ---------- 상태 코드 enum ----------
class St(enum.IntEnum):
    SENT = 1
    SUCCESS = 2
    FAIL = 3

# ---------- DB 커넥션 ----------
@contextmanager
def db():
    conn = pymysql.connect(**DB)
    try:
        yield conn.cursor()
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

# ----------------------------------------------------------------------
# 0) 뉴스+유저 조회
# ----------------------------------------------------------------------
def fetch_targets():
    q = """
    SELECT c.id   AS cid,
           k.keyword,
           n.title, n.link,
           u.id   AS uid,
           u.email
      FROM crolling  c
      JOIN keyword   k ON k.id = c.keyword_id
      JOIN news      n ON n.crolling_id = c.id
      JOIN subscribe s ON s.keyword_id = k.id
      JOIN users     u ON u.id = s.user_id
     WHERE c.is_send = 0
    ORDER BY c.id
    """
    with db() as cur:
        cur.execute(q)
        return cur.fetchall()

# ----------------------------------------------------------------------
# 1) 이메일 발송 (사용자 1명당 메일 1통, 키워드별 뉴스 포함)
# ----------------------------------------------------------------------
def send_via_ses(email: str, news_by_keyword: dict, date_str: str):
    subject = f"[뉴스 알림] ({date_str})"

    body_lines = [
        f"안녕하세요. {email} 구독자님\n\n다음 키워드에 대한 새로운 뉴스가 등록되었습니다.\n"
    ]

    for keyword, news_list in news_by_keyword.items():
        body_lines.append(f"[{keyword}]")
        for title, link in news_list:
            body_lines.append(f"• {title} : {link}")
        body_lines.append("")  # 키워드 간 줄바꿈

    body_lines.append("👉 전체 뉴스 보기: https://yourdomain.com/news")
    body_lines.append("감사합니다.")
    body_text = "\n".join(body_lines)

    ses.send_email(
        Source=SES_SENDER,
        Destination={"ToAddresses": [email]},
        Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {
                "Text": {"Data": body_text, "Charset": "UTF-8"}
            }
        }
    )

# ----------------------------------------------------------------------
# 2) 발송 이력 기록 + 상태 변경
# ----------------------------------------------------------------------
def add_history(uid: int, cid: int) -> int:
    with db() as cur:
        cur.execute(
            """
            INSERT IGNORE INTO send_history (user_id, crolling_id, send_status_id, sent_at)
            VALUES (%s, %s, %s, %s)
            """,
            (uid, cid, St.SENT, datetime.now(timezone.utc)),
        )
        return cur.lastrowid

def update_history(hid: int, status: St):
    with db() as cur:
        cur.execute(
            "UPDATE send_history SET send_status_id=%s, sent_at=%s WHERE id=%s",
            (status, datetime.now(timezone.utc), hid),
        )

def mark_sent(cids: set[int]):
    if not cids:
        return
    with db() as cur:
        cur.executemany(
            "UPDATE crolling SET is_send = 1 WHERE id = %s",
            [(cid,) for cid in cids]
        )

# ----------------------------------------------------------------------
# 3) Lambda Entry Point
# ----------------------------------------------------------------------
def lambda_handler(event, context):
    rows = fetch_targets()
    if not rows:
        return {"statusCode": 200, "body": json.dumps({"msg": "no new items"})}

    today = datetime.now().strftime("%Y-%m-%d")
    grouped = defaultdict(lambda: {
        "news_by_keyword": defaultdict(list),
        "uids": set(),
        "cids": set()
    })

    # (이메일) 기준으로 그룹핑, 키워드별로 뉴스 모음
    for r in rows:
        email = r["email"]
        keyword = r["keyword"]
        grouped[email]["news_by_keyword"][keyword].append((r["title"], r["link"]))
        grouped[email]["uids"].add(r["uid"])
        grouped[email]["cids"].add(r["cid"])

    # 이메일 1통씩만 발송
    for email, data in grouped.items():
        uid = list(data["uids"])[0]
        cid = list(data["cids"])[0]
        hid = add_history(uid, cid)

        try:
            send_via_ses(email, data["news_by_keyword"], today)
            update_history(hid, St.SUCCESS)
        except Exception:
            print(f"SES FAIL: email={email}")
            traceback.print_exc()
            update_history(hid, St.FAIL)

        mark_sent(data["cids"])

    return {"statusCode": 200, "body": json.dumps({"msg": f"processed {len(grouped)} users"})}
