# ---------- 기본 의존 ----------
import enum, json, pymysql, boto3, traceback
from datetime import datetime, timezone
from contextlib import contextmanager

# ---------- DB 설정 ----------
DB = dict(
    host="ns-rds.cb0ueo6m8a54.ap-northeast-2.rds.amazonaws.com",
    user="root",
    password="soldesk12!",
    database="NewsSubscribe",
    charset="utf8mb4",
    cursorclass=pymysql.cursors.DictCursor
)

# ---------- SES 설정 ----------
ses = boto3.client("ses", region_name="ap-northeast-2")
SES_SENDER = "fun.helen3914@gmail.com"  # 🔴 SES 인증된 이메일 주소로 변경해야 함

# ---------- 상태 코드 enum ----------
class St(enum.IntEnum):
    SENT = 1
    SUCCESS = 2
    FAIL = 3

# ---------- DB 커넥션 ----------
@contextmanager
def db():
    conn = pymysql.connect(**DB)
    try:
        yield conn.cursor()
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

# ----------------------------------------------------------------------
# 0) 뉴스+유저 조회 (크롤링 결과 존재하는 구독자 기준)
# ----------------------------------------------------------------------
def fetch_targets():
    q = """
    SELECT c.id   AS cid,
           k.keyword,
           n.title, n.link,
           u.id   AS uid,
           u.email
      FROM crolling  c
      JOIN keyword   k ON k.id = c.keyword_id
      JOIN news      n ON n.crolling_id = c.id
      JOIN subscribe s ON s.keyword_id = k.id
      JOIN users     u ON u.id = s.user_id
     WHERE c.is_send = 0
    ORDER BY c.id
    """
    with db() as cur:
        cur.execute(q)
        return cur.fetchall()

# ----------------------------------------------------------------------
# 1) 이메일 발송 (SES 사용) ✅ SNS → SES 변경
# ----------------------------------------------------------------------
def send_via_ses(email: str, keyword: str, title: str, link: str, date_str: str):
    subject = f"[뉴스] {keyword} ({date_str})"
    body_text = (
        f"안녕하세요. {email} 구독자님\n\n"
        f"'{keyword}' 키워드에 대한 새로운 뉴스가 등록되었습니다.\n\n"
        f"• {title} : {link}\n\n"
        "👉 뉴스 보기: https://yourdomain.com/news\n\n"
        "감사합니다."
    )

    ses.send_email(
        Source=SES_SENDER,
        Destination={"ToAddresses": [email]},
        Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {
                "Text": {"Data": body_text, "Charset": "UTF-8"}
            }
        }
    )

# ----------------------------------------------------------------------
# 2) 발송 이력 기록 + 상태 변경
# ----------------------------------------------------------------------
def add_history(uid: int, cid: int) -> int:
    with db() as cur:
        cur.execute(
            """
            INSERT IGNORE INTO send_history (user_id, crolling_id, send_status_id, sent_at)
            VALUES (%s, %s, %s, %s)
            """,
            (uid, cid, St.SENT, datetime.now(timezone.utc)),
        )
        return cur.lastrowid

def update_history(hid: int, status: St):
    with db() as cur:
        cur.execute(
            "UPDATE send_history SET send_status_id=%s, sent_at=%s WHERE id=%s",
            (status, datetime.now(timezone.utc), hid),
        )

def mark_sent(cids: set[int]):
    if not cids:
        return
    with db() as cur:
        cur.executemany(
            "UPDATE crolling SET is_send = 1 WHERE id = %s",
            [(cid,) for cid in cids]
        )

# ----------------------------------------------------------------------
# 3) Lambda Entry Point
# ----------------------------------------------------------------------
def lambda_handler(event, context):
    rows = fetch_targets()
    if not rows:
        return {"statusCode": 200, "body": json.dumps({"msg": "no new items"})}

    processed = set()
    today = datetime.now().strftime("%Y-%m-%d")

    for r in rows:
        hid = add_history(r["uid"], r["cid"])
        try:
            send_via_ses(r["email"], r["keyword"], r["title"], r["link"], today)
            update_history(hid, St.SUCCESS)
        except Exception as e:
            print(f"SES FAIL: user_id={r['uid']}, crolling_id={r['cid']}")
            traceback.print_exc()
            update_history(hid, St.FAIL)

        processed.add(r["cid"])

    mark_sent(processed)
    return {"statusCode": 200, "body": json.dumps({"msg": f"processed {len(rows)}"})}
